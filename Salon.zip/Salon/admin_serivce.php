<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');

$sql = "SELECT * FROM services";
$result = mysqli_query($conn, $sql);
$num_rows = mysqli_num_rows($result);

$sqllist = "SELECT * FROM services_list";
$resultlist = mysqli_query($conn, $sqllist);
$num_rowslist = mysqli_num_rows($resultlist);

?>
<main id="main">
  <section class="inner-page">
    <div class="container">
      <div class="section-title">
        <h2>รายการบริการ</h2>
      </div>
      <div class="card">
        <div class="card-header">
          รายชื่อลูกค้า
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12">
              <?php
              if (isset($_SESSION['errorsddcus']) && $_SESSION['errorsddcus'] != "") {
              ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo $_SESSION['errorsddcus']; ?>
                </div>
              <?php
                unset($_SESSION['errorsddcus']);
              }
              if (isset($_SESSION['successaddcus']) && $_SESSION['successaddcus'] != "" && $_SESSION['successaddcus'] == "Regis commplet") {
              ?>
                <div class="alert alert-success" role="alert">
                  เพิ่มข้อมูลเรียบร้อย
                </div>
              <?php
                unset($_SESSION['successaddcus']);
              }
              ?>
            </div>
          </div>
          <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addservice">เพิ่มบริการ</a>
          <div class="row">
            <div class="col-12">
              <table class="table table-hover table-sm  ">
                <thead>
                  <tr class="table-primary">
                    <th scope="col">รหัสบริการ</th>
                    <th scope="col">ชื่อบริการ</th>
                    <th scope="col">ประเภทบริการ</th>
                    <th scope="col">ราคา</th>
                    <th scope="col">รูปตัวอย่าง</th>
                    <th scope="col">#</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  //<!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id`  class="img-fluid img-thumbnail" -->
                  while ($row = mysqli_fetch_assoc($result)) {
                  ?>
                    <tr>
                      <td>SER<?php echo $row['ser_id']; ?></td>
                      <td><?php echo $row['ser_name']; ?></td>
                      <td><?php echo $row['ser_list']; ?></td>
                      <td><?php echo $row['ser_price']; ?></td>
                      <td><img src="img/services/<?php echo $row['ser_photo']; ?>" class="img-thumbnail" style="width:200px;"></td>
                      <td><button class="btn btn-sm btn-primary">แก้ไข</button><button class="btn btn-sm btn-danger">ลบ</button></td>
                    </tr>

                  <?php
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- Modal addcus -->
  <div class="modal fade" id="addservice" tabindex="-1" aria-labelledby="addserviceLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addserviceLabel">เพิ่มบริการ</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="config/manage_servicedb.php" method="post" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="form-group mb-3">
              <label for="ser_list" class="col-form-label">ประเภทบริการ</label>
              <select name="ser_list" id="ser_listselect" class="form-control">
                <option value="">เลือกประเภทบริการ</option>
                <?php
                while ($row = mysqli_fetch_assoc($resultlist)) {

                ?>
                  <option value="<?php echo $row['service_list']; ?>"><?php echo $row['service_list']; ?></option>
                <?php
                }
                ?>
              </select>
            </div>
            <div class="form-group mb-3">
              <!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id` -->
              <label for="ser_name" class="col-form-label">ชื่อบริการ</label>
              <input type="text" name="ser_name" class="form-control" id="ser_name" required>
            </div>

            <div class="form-group mb-3">
              <label for="ser_list" class="col-form-label">รายละเอียดบริการ</label>
              <input type="text" name="ser_detail" class="form-control" id="ser_detail" required>
            </div>
            <div class="form-group mb-3">
              <label for="fileupload">ตัวอย่างบริการ</label>
              <input class="form-control" type="file" id="fileupload" name="fileupload" required>

            </div>
            <div class="form-group mb-3">
              <label for="ser_price">ราคา</label>
              <input type="number" class="form-control" name="ser_price" id="ser_price" required>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
            <button type="submit" class="btn btn-primary" name="addserbtn">ยืนยัน</button>
          </div>
        </form>
      </div>
    </div>
  </div>

</main><!-- End #main -->
<?php
include('include/foot.php');
mysqli_close($conn);
?>