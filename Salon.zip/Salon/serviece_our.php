<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');

$sql = "SELECT * FROM services";
$result = mysqli_query($conn, $sql);
$num_rows = mysqli_num_rows($result);

$sqllist = "SELECT * FROM services_list";
$resultlist = mysqli_query($conn, $sqllist);
$num_rowslist = mysqli_num_rows($resultlist);

?>
<main id="main">
  <section class="inner-page">
    <div class="container">
      <div class="section-title">
        <h2>รายการบริการ</h2>
      </div>
      <div class="card">
        <div class="card-header">
          รายการบริการทั้งหมด
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12">

            </div>
          </div>
          
          <div class="row">
            <div class="col-12">
              <table class="table table-hover table-sm" id="table1">
                <thead>
                  <tr class="table-primary">
                    <th scope="col">รหัสบริการ</th>
                    <th scope="col">ชื่อบริการ</th>
                    <th scope="col">ประเภทบริการ</th>
                    <th scope="col">ราคา</th>
                    <th scope="col">รูปตัวอย่าง</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  //<!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id`  class="img-fluid img-thumbnail" -->
                  while ($row = mysqli_fetch_assoc($result)) {
                  ?>
                    <tr>
                      <td>SER<?php echo $row['ser_id']; ?></td>
                      <td><?php echo $row['ser_name']; ?></td>
                      <td><?php echo $row['ser_list']; ?></td>
                      <td><?php echo $row['ser_price']; ?></td>
                      <td><img src="img/services/<?php echo $row['ser_photo']; ?>" class="img-thumbnail" style="width:200px;"></td>
                    </tr>

                  <?php
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>



</main><!-- End #main -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
        $(document).ready(function () {
            $("#table1").DataTable();
        });
</script>
</script>
<?php
include('include/foot.php');
mysqli_close($conn);
?>