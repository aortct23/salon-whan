<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if ($role == "customer") {
  $sql = "SELECT cus_user as username,cus_name as firstname,cus_phone as  phone,cus_email as  email,cus_password as  password ,cus_photo as photo
          FROM customers WHERE (cus_user='$username' or cus_phone ='$username') ";
  $urole = "ลูกค้า";
} else if ($role == "emp") {
  $sql = "SELECT tr_user as username,tr_name as firstname,tr_tel as  phone,tr_email as email,tr_password as password ,tr_photo as photo
          FROM employees WHERE (tr_user='$username' or tr_tel ='$username') ";
  $urole = "ช่างประจำร้าน";
} else if ($role == "admin") {
  $sql = "SELECT ad_name as username,ad_user as firstname,ad_phone as  phone,ad_email as email,ad_password as password ,ad_photo as photo
          FROM admin WHERE (ad_user='$username' or ad_phone ='$username')  ";
  $urole = "เจ้าของร้าน";
}
$query = $sql;
$result = mysqli_query($conn, $query);
$phone = "";
$email = "";
$password = "";
$firname = "";
$photo = "";
if ($result) {
  if (mysqli_num_rows($result) == 1) {
    while ($row = mysqli_fetch_assoc($result)) {
      $firname = $row['firstname'];
      $phone = $row['phone'];
      $email = $row['email'];
      $password = $row['password'];
      $photo = $row['photo'];
    }
  }
}
//if (isset($_GET["idpay"]) &&isset($_GET["price"])
?>
<main>
  <!-- ======= About Section ======= -->
  <section id="about" class="about">
    <div class="container">

      <div class="section-title">
        <h2>ประวัติส่วนตัว</h2>
      </div>

      <div class="row">
        <div class="col-lg-4" data-aos="fade-right">
          <?php
          if (isset($photo) && $photo != "") {
            echo '<img src="img/profile/' . $photo . '" class="img-thumbnail rounded" alt="">';
          } else {
            echo '<img src="assets/img/alopecia.png" class="img-thumbnail rounded" alt="">';
          }
          ?>

          <div class="row">
            <form action="config/edit_photo.php" method="POST" enctype="multipart/form-data">
              <div class="form-group">
                <label for="username">แก้ไขรูปประจำตัว</label>
                <input class="form-control" type="file" id="fileupload" name="fileupload" required>
              </div>
              <button type="submit" class="btn btn-primary" name="editphobtn">ยืนยัน</button>
            </form>
          </div>
        </div>
        <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
          <h3>ชื่อ <?php echo $firname; ?> :ระดับ <?php echo $urole; ?></h3>
          <div class="row">
            <div class="col-lg-12">
              <ul>
                <li><i class="bi bi-chevron-right"></i> <strong>ชื่อผู้ใช้งาน:</strong> <span><?php echo $urole; ?></span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>เบอร์โทรศัพท์:</strong> <span><?php echo $phone; ?></span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?php echo $email; ?></span></li>
                <li><i class="bi bi-chevron-right"></i> <strong>รหัสผ่าน:</strong> <span><?php echo $password; ?></span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End About Section -->
</main>
<?php
include('include/foot.php');
mysqli_close($conn);
?>