<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');

$sql = "SELECT * FROM services ORDER BY ser_list";
$result = mysqli_query($conn, $sql);
$num_rows = mysqli_num_rows($result);

$sqllist = "SELECT * FROM services_list";
$resultlist = mysqli_query($conn, $sqllist);
$num_rowslist = mysqli_num_rows($resultlist);

?>
<main id="main">
    <section class="inner-page">
        <div class="container">
            <div class="section-title">
                <h2>รายการบริการ</h2>
            </div>
            <div class="card">
                <h5 class="card-header">คุณกำลังจองคิว กรุณาใส่ข้อมูล</h5>
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <form action="config/reservation_db.php" method="post">
                                
                                <!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id`  class="img-fluid img-thumbnail" -->
                                <!--`reservations`(`reser_id`, `reser_date`, `reser_time`, `tr_id`, `ser_id`, `cus_id`) -->
                                <div class="mb-3 row">
                                    <label for="inputdate" class="col-sm-2 col-form-label">ชื่อบริการ</label>
                                    <div class="col-sm-10">
                                        <select name="ser_id" id="ser_listselect" class="form-control">
                                            <option value="">เลือกบริการ</option>
                                            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                                <option value="<?php echo $row['ser_id']; ?>"><?php echo $row['ser_name']."-".$row['ser_price'].".-"; ?></option>
                                            <?php }  ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputdate" class="col-sm-2 col-form-label">วันที่จอง</label>
                                    <div class="col-sm-10">

                                        <input type="date" class="form-control" id="inputdate" name="datebook" onchange="getEmp();">


                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputtime" class="col-sm-2 col-form-label">เวลาที่จอง</label>
                                    <div class="col-sm-10">
                                        <select name="timebook" id="timebook" class="form-control" onchange="getEmp();">
                                            <option value="">เลือกเวลา</option>
                                            <option value="09:00">09:00</option>
                                            <option value="10:00">10:00</option>
                                            <option value="11:00">11:00</option>
                                            <option value="12:00">12:00</option>
                                            <option value="13:00">13:00</option>
                                            <option value="14:00">14:00</option>
                                            <option value="15:00">15:00</option>
                                            <option value="16:00">16:00</option>
                                            <option value="17:00">17:00</option>
                                        </select>
                                        <!-- <input type="time" class="form-control" id="inputtime" > -->
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="selectservices" class="col-sm-2 col-form-label">รายชื่อช่างที่ว่าง</label>
                                    <div class="col-sm-10">
                                        <select name="employee" id="employee" class="form-control">
                                            <option value="">เลือกช่าง</option>

                                        </select>

                                        <p><?php if (isset($_SESSION["sql"])) {
                                                echo $_SESSION["sql"];
                                                unset($_SESSION["sql"]);
                                            } ?></p>
                                        <!-- <input type="text" class="form-control" id="selectservice"> -->
                                    </div>
                                </div>


                                <div class="mb-3 row">
                                    <button type="submit" class="btn btn-primary" name="add">ยืนยันการจอง</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>



</main><!-- End #main -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $("#table1").DataTable();
    });
</script>
<script type="text/javascript">
  function getEmp() {
    $("#employee").empty();
    var date =document.getElementById("inputdate").value;
    var time = document.getElementById("timebook").value;

    $.ajax({
      url:"config/getEmp.php",
      method:"POST",
      data:{
        date: date,
        time :time
      },
      success:function(data){
        
        $("#employee").html(data);
      }
    })

  }

</script>
<?php
include('include/foot.php');
mysqli_close($conn);
?>