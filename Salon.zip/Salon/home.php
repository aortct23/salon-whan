  <?php
  session_start();
  //$_SESSION["username"]="";
  include('include/header.php');
  include('config/condb.php');

  ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1>น้ำหวาน ซาลอน</h1>
      <p><span class="typed" data-typed-items="ยินดีต้อนรับ ร้านเสริมสวยครบวงจร"></span></p>
      <?php
  if (!isset($_SESSION["username"])||$_SESSION["username"]=="") {
?>
<a href="#login" class="scrollto btn btn-lg btn-outline-dark"> ลงทะเบียน/เข้าสู่ระบบ</a>
<?php
  } else { 

?>
 <a href="resevation.php" class="scrollto btn btn-lg btn-outline-dark"> จองคิวเดี๋ยวนี้!!</a>
<?php
  }
  ?>
     
    </div>
  </section><!-- End Hero -->

  <?php
  if (!isset($_SESSION["username"])||$_SESSION["username"]=="") {
    include('login.php');
  }
  ?>
  
  <?php
  include('include/foot.php');
  mysqli_close($conn);
  ?>