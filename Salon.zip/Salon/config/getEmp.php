<?php
session_start();
include('condb.php');
$date = $_POST["date"];
$time = $_POST["time"];
//employees(tr_name,tr_tel,tr_user,tr_email,tr_password) 
$select ="SELECT u.tr_id,u.tr_name,u.tr_user from  ( 
    select  tr_id,tr_name,tr_user from employees ) u 
    left join (select tr_id from reservations where date_format(reser_date,'%Y-%m-%d')='{$date}' and reser_time='{$time}' and (status ='confirm' or status ='new' )  ) b 
    on u.tr_id = b.tr_id 
    where b.tr_id is null ";
//date_format(booking_date,'%Y-%m-%d')='{$date}' and
$result = mysqli_query($conn, $select);
$num_rows = mysqli_num_rows($result);

if ($num_rows == 0) {
?>
    <option value="">เลือกช่าง</option>
    <option value=""><?php echo $select; ?></option>

    <?php
} else {

    ?>
    <option value="">เลือกช่าง</option>
    <?php
    while ($row = mysqli_fetch_array($result)) {
    ?>
        <option value="<?php echo $row['tr_id']; ?>"><?php echo $row['tr_name']; ?></option>
<?php
    }
}
//$_SESSION["sql"] = $select;

?>