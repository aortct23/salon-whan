<?php 
    session_start();
    include('condb.php');

    $errors = array();

    if(isset($_POST['addcusbtn'])) {
        $cus_name = mysqli_real_escape_string($conn,$_POST['cus_name']);
        $cus_user = mysqli_real_escape_string($conn,$_POST['cus_user']);
        $cus_phone = mysqli_real_escape_string($conn,$_POST['cus_phone']);
        $cus_email = mysqli_real_escape_string($conn,$_POST['cus_email']);


        if(empty($cus_user)){
            array_push($errors,"กรุณาระบุชื่อผู้ใช้");
        }
        if(empty($cus_phone)){
            array_push($errors,"กรุณาระบุเบอร์โทรศัพท์");
        }

        $user_check_query = "SELECT * FROM customers WHERE cus_user='$cus_user' OR cus_phone ='$cus_phone' ";
        $query = mysqli_query($conn,$user_check_query);
        $result = mysqli_fetch_assoc($query);

        if($result) {
            if($result['cus_user']=== $cus_user){
                array_push($errors,"Username นี้มีคนใช้งานแล้ว");
            }

            if($result['cus_phone']=== $cus_phone){
                array_push($errors,"เบอร์โทรศัพท์นี้มีคนใช้งานแล้ว");
            }
        }

        if(count($errors)==0){
            $passwordreal = $password;
            $username = strtolower($username);
            $sql = "INSERT INTO customers(cus_name,cus_phone,cus_user,cus_email,cus_password) VALUES ('$cus_name','$cus_phone','$cus_user','$cus_email','$cus_phone')";

            mysqli_query($conn,$sql);

            // $_SESSION['username'] = $username;
            // $_SESSION['urole'] = "customer";
             $_SESSION['successaddcus'] = "Regis commplet";
             echo $sql;
             //echo "<script> alert('".$varerr."'); window.location = '../home.php'; </script>";
            header('location: ../admin_usermanage.php');
        }
        else
        {
            $varerr="";
            foreach($errors as $e )
            {
                $varerr .= $e ;
                $varerr .= "<br/>";
            }
                echo $varerr;
           
            //array_push($error,"Username นี้มีคนใช้งานแล้ว");
            $_SESSION['errorsddcus']= $varerr; 
            echo "<script> alert('".$varerr."'); window.location = '../home.php#login'; </script>";
           header('location: ../admin_usermanage.php');
        }

    }

    if(isset($_POST['addempbtn'])) {
        $tr_name = mysqli_real_escape_string($conn,$_POST['tr_name']);
        $tr_user = mysqli_real_escape_string($conn,$_POST['tr_user']);
        $tr_tel = mysqli_real_escape_string($conn,$_POST['tr_tel']);
        $tr_email = mysqli_real_escape_string($conn,$_POST['tr_email']);


        if(empty($tr_user)){
            array_push($errors,"กรุณาระบุชื่อผู้ใช้");
        }
        if(empty($tr_tel)){
            array_push($errors,"กรุณาระบุเบอร์โทรศัพท์");
        }

        $user_check_query = "SELECT * FROM employees WHERE tr_user='$tr_user' OR tr_tel ='$tr_tel' ";
        $query = mysqli_query($conn,$user_check_query);
        $result = mysqli_fetch_assoc($query);

        if($result) {
            if($result['tr_user']=== $tr_user){
                array_push($errors,"Username นี้มีคนใช้งานแล้ว");
            }

            if($result['tr_tel']=== $tr_tel){
                array_push($errors,"เบอร์โทรศัพท์นี้มีคนใช้งานแล้ว");
            }
        }

        if(count($errors)==0){
            $passwordreal = $password;
            $username = strtolower($username);
            $sql = "INSERT INTO employees(tr_name,tr_tel,tr_user,tr_email,tr_password) VALUES ('$tr_name','$tr_tel','$tr_user','$tr_email','$tr_tel')";

            mysqli_query($conn,$sql);

            // $_SESSION['username'] = $username;
            // $_SESSION['urole'] = "customer";
             $_SESSION['successaddemp'] = "Regis commplet";
             echo $sql;
             //echo "<script> alert('".$varerr."'); window.location = '../home.php'; </script>";
            header('location: ../admin_usermanage.php');
        }
        else
        {
            $varerr="";
            foreach($errors as $e )
            {
                $varerr .= $e ;
                $varerr .= "<br/>";
            }
                echo $varerr;
           
            //array_push($error,"Username นี้มีคนใช้งานแล้ว");
            $_SESSION['errorsddemp']= $varerr; 
            echo "<script> alert('".$varerr."'); window.location = '../home.php#login'; </script>";
           header('location: ../admin_usermanage.php');
        }

    }

    if(isset($_POST['addadminbtn'])) {
        $ad_name = mysqli_real_escape_string($conn,$_POST['ad_name']);
        $ad_user = mysqli_real_escape_string($conn,$_POST['ad_user']);
        $ad_phone = mysqli_real_escape_string($conn,$_POST['ad_phone']);
        $ad_email = mysqli_real_escape_string($conn,$_POST['ad_email']);


        if(empty($ad_user)){
            array_push($errors,"กรุณาระบุชื่อผู้ใช้");
        }
        if(empty($ad_phone)){
            array_push($errors,"กรุณาระบุเบอร์โทรศัพท์");
        }

        $user_check_query = "SELECT * FROM admin WHERE ad_user='$ad_user' OR ad_phone ='$ad_phone' ";
        $query = mysqli_query($conn,$user_check_query);
        $result = mysqli_fetch_assoc($query);

        if($result) {
            if($result['ad_user']=== $ad_user){
                array_push($errors,"Username นี้มีคนใช้งานแล้ว");
            }

            if($result['ad_phone']=== $ad_phone){
                array_push($errors,"เบอร์โทรศัพท์นี้มีคนใช้งานแล้ว");
            }
        }

        if(count($errors)==0){
            $passwordreal = $password;
            $username = strtolower($username);
            //(`ad_id`, `ad_name`, `ad_phone`, `ad_user`, `ad_email`, `ad_password`
            $sql = "INSERT INTO admin(ad_name,ad_phone,ad_user,ad_email,ad_password) VALUES ('$ad_name','$ad_phone','$ad_user','$ad_email','$ad_phone')";

            mysqli_query($conn,$sql);

            // $_SESSION['username'] = $username;
            // $_SESSION['urole'] = "customer";
             $_SESSION['successaddadmin'] = "Regis commplet";
             echo $sql;
             //echo "<script> alert('".$varerr."'); window.location = '../home.php'; </script>";
            header('location: ../admin_usermanage.php');
        }
        else
        {
            $varerr="";
            foreach($errors as $e )
            {
                $varerr .= $e ;
                $varerr .= "<br/>";
            }
                echo $varerr;
           
            //array_push($error,"Username นี้มีคนใช้งานแล้ว");
            $_SESSION['errorsddadmin']= $varerr; 
            echo "<script> alert('".$varerr."'); window.location = '../home.php#login'; </script>";
           header('location: ../admin_usermanage.php');
        }

    }
?>