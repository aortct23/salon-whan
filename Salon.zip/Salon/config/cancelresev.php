<?php 
session_start();
include('condb.php');
 if (isset($_GET["reserid"])){
    $reser_id = $_GET["reserid"];
    $query = "SELECT * FROM reservations WHERE reser_id=$reser_id ";
    $result = mysqli_query($conn, $query);
    if($result){
        $updateslip = "UPDATE reservations SET status='cancel' WHERE reser_id ={$reser_id}";
        $resultx = mysqli_query($conn, $updateslip);
        $_SESSION['successregid'] = "Regis commplet";
        echo $sql;
             //echo "<script> alert('".$varerr."'); window.location = '../home.php'; </script>";
            header('location: ../admin_reservation.php');
    }
 }
?>