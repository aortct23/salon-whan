-- create table admin
CREATE TABLE
    `id21244256_salon`.`admin` (
        `ad_id` INT NOT NULL AUTO_INCREMENT,
        `ad_name` VARCHAR(100) NOT NULL,
        `ad_phone` VARCHAR(20) NOT NULL,
        `ad_user` VARCHAR(20) NOT NULL,
        `ad_email` VARCHAR(100) NULL,
        `ad_password` VARCHAR(20) NOT NULL,
        PRIMARY KEY (`ad_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`customers` (
        `cus_id` INT NOT NULL AUTO_INCREMENT,
        `cus_name` VARCHAR(100) NOT NULL,
        `cus_phone` VARCHAR(20) NOT NULL,
        `cus_user` VARCHAR(20) NOT NULL,
        `cus_email` VARCHAR(100) NULL,
        `cus_password` VARCHAR(20) NOT NULL,
        PRIMARY KEY (`cus_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`services` (
        `ser_id` INT NOT NULL AUTO_INCREMENT,
        `ser_name` VARCHAR(100) NOT NULL,
        `ser_list` VARCHAR(100) NOT NULL,
        `ser_detail` TEXT NULL,
        `ser_photo` VARCHAR(255) NULL,
        `ser_price` INT NOT NULL,
        `tr_id` INT NULL,
        PRIMARY KEY (`ser_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`reservations` (
        `reser_id` INT NOT NULL AUTO_INCREMENT,
        `reser_date` DATE NOT NULL,
        `reser_time` VARCHAR(100) NOT NULL,
        `tr_id` INT NOT NULL,
        `ser_id` INT NOT NULL,
        `cus_id` INT NOT NULL,
        PRIMARY KEY (`reser_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`employees` (
        `tr_id` INT NOT NULL AUTO_INCREMENT,
        `tr_name` VARCHAR(255) NOT NULL,
        `tr_tel` VARCHAR(30) NOT NULL,
        `tr_user` VARCHAR(100) NOT NULL,
        `tr_email` VARCHAR(255) NULL,
        `tr_password` VARCHAR(100) NOT NULL,
        `tr_ photo` VARCHAR(255) NOT NULL,
        PRIMARY KEY (`tr_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`times_service` (
        `times_id` INT NOT NULL AUTO_INCREMENT,
        `times_date` DATE NOT NULL,
        `times_time` VARCHAR(100) NOT NULL,
        `tr_id` INT NOT NULL,
        PRIMARY KEY (`times_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21244256_salon`.`work_schedule` (
        `work_id` INT NOT NULL AUTO_INCREMENT,
        `reser_id` INT NOT NULL,
        `tr_id` INT NOT NULL,
        `cus_id` INT NOT NULL,
        PRIMARY KEY (`work_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;

CREATE TABLE
    `id21333175_salon`.`services_list` (
        `serlist_id` INT NOT NULL AUTO_INCREMENT,
        `service_list` VARCHAR(100) NOT NULL,
        PRIMARY KEY (`serlist_id`)
    ) ENGINE = InnoDB CHARSET = utf8 COLLATE utf8_general_ci;