<?php 

session_start();

include('condb.php');

if(isset($_POST["addserbtn"])) {
//<!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id` -->
    $fileupload = $_POST["fileupload"];
    $ser_name = mysqli_real_escape_string($conn,$_POST['ser_name']);
    $ser_list = mysqli_real_escape_string($conn,$_POST['ser_list']);
    $ser_detail = mysqli_real_escape_string($conn,$_POST['ser_detail']);
    $ser_price = mysqli_real_escape_string($conn,$_POST['ser_price']);

    date_default_timezone_set('Asia/Bangkok');
    $date = date("Ymd");

    $numrand = (mt_rand());
    $upload = $_FILES["fileupload"];
    $newname="";
    $path="";
    if($upload !="")  {
        $path ="../img/services/"; 
        $type = strrchr($_FILES['fileupload']['name'],".");

        $newname = $date.$numrand.$type;
        $path_copy=$path.$newname;
        $path_link="../img/services/".$newname;

        move_uploaded_file($_FILES["fileupload"]["tmp_name"],$path_copy);

    }
//echo $path;
    $updateslip="INSERT INTO services(ser_name,ser_list,ser_detail,ser_photo,ser_price) VALUES ('$ser_name','$ser_list','$ser_detail','$newname',$ser_price)";

    $result = mysqli_query($conn,$updateslip) or die ("Error in query : $updateslip ".mysqli_error($conn));

    mysqli_close($conn);

    if($result){
        echo "<script type='text/javascript'>
        alert('สำเร็จ');
        window.location = '../admin_serivce.php';
        </script>";
    }else{
        echo "<script type='text/javascript'>
        alert('ไม่สำเร็จ');
        window.location = '../admin_serivce.php';
        </script>";
    }
}
?>