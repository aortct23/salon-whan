<?php 
    session_start();
    include('condb.php');

    $errors = array();

    if(isset($_POST['registbtn'])) {
        $cus_name = mysqli_real_escape_string($conn,$_POST['cus_name']);
        $cus_user = mysqli_real_escape_string($conn,$_POST['cus_user']);
        $cus_phone = mysqli_real_escape_string($conn,$_POST['cus_phone']);
        $cus_email = mysqli_real_escape_string($conn,$_POST['cus_email']);
        $cus_password = mysqli_real_escape_string($conn,$_POST['cus_password']);
        $repassword = mysqli_real_escape_string($conn,$_POST['repassword']);
        echo $cus_name;
        echo $cus_user;
        echo $cus_phone;
        echo $cus_email;
        echo $cus_password;
        echo $repassword;

        if(empty($cus_user)){
            array_push($errors,"กรุณาระบุชื่อผู้ใช้");
        }
        if(empty($cus_phone)){
            array_push($errors,"กรุณาระบุเบอร์โทรศัพท์");
        }
        if(empty($cus_password)){
            array_push($errors,"กรุณาระบุรหัสผ่าน");
        }
        if(empty($repassword)){
            array_push($errors,"กรุณาระบุรหัสผ่าน");
        }

        if($cus_password != $repassword){
            array_push($errors,"รหัสผ่านไม่ตรงกันกรุณาใส่ใหม่");
        }

        $user_check_query = "SELECT * FROM customers WHERE cus_user='$cus_user' OR cus_phone ='$cus_phone' ";
        $query = mysqli_query($conn,$user_check_query);
        $result = mysqli_fetch_assoc($query);

        if($result) {
            if($result['cus_user']=== $cus_user){
                array_push($errors,"Username นี้มีคนใช้งานแล้ว");
            }

            if($result['cus_phone']=== $cus_phone){
                array_push($errors,"เบอร์โทรศัพท์นี้มีคนใช้งานแล้ว");
            }
        }

        if(count($errors)==0){
            $passwordreal = $password;
            $username = strtolower($username);
            $sql = "INSERT INTO customers(cus_name,cus_phone,cus_user,cus_email,cus_password) VALUES ('$cus_name','$cus_phone','$cus_user','$cus_email','$cus_password')";

            mysqli_query($conn,$sql);

            // $_SESSION['username'] = $username;
            // $_SESSION['urole'] = "customer";
             $_SESSION['successregid'] = "Regis commplet";
             echo $sql;
             //echo "<script> alert('".$varerr."'); window.location = '../home.php'; </script>";
            header('location: ../home.php#login');
        }
        else
        {
            $varerr="";
            foreach($errors as $e )
            {
                $varerr .= $e ;
                $varerr .= "<br/>";
            }
                echo $varerr;
           
            //array_push($error,"Username นี้มีคนใช้งานแล้ว");
            $_SESSION['errorregis']= $varerr; 
            echo "<script> alert('".$varerr."'); window.location = '../home.php#login'; </script>";
           header('location: ../home.php#login');
        }

    }
?>
