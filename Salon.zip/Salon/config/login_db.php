<?php 
session_start();
include('condb.php');
$errors = array();

if(isset($_POST['login_user'])) {
    $username = mysqli_real_escape_string($conn,$_POST['logingname']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $role = mysqli_real_escape_string($conn,$_POST['urole']);

    if(empty($username)){
        array_push($errors,"กรุณาใส่ชื่อผู้ใช้งาน");
    }

    if(empty($password)){
        array_push($errors,"กรุณาใส่รหัสผ่าน");
    }

    if(count($errors)==0){
        $sql ="";
        $username = strtolower($username);
        if($role=="customer"){
            $sql ="SELECT cus_id as id,cus_user as username,cus_name as firstname FROM customers WHERE (cus_user='$username' or cus_phone ='$username')   and cus_password='$password'"; 
        }else if($role=="emp"){
            $sql ="SELECT tr_id as id,tr_user as username,tr_name as firstname FROM employees WHERE (tr_user='$username' or tr_tel ='$username')   and tr_password='$password'"; 
        }else if($role=="admin"){
            $sql ="SELECT ad_id as id,ad_name as username,ad_user as firstname FROM admin WHERE (ad_user='$username' or ad_phone ='$username')   and ad_password='$password'"; 
        }

        
        $query = $sql;
        $result = mysqli_query($conn,$query);
        if($result){
            if(mysqli_num_rows($result)==1){
                while ($row = mysqli_fetch_assoc($result)) {
                    $namefirt = $row['firstname'];
                    $username =  $row['username'];
                    $id =  $row['id'];
                }
                $_SESSION['role'] = $role;
                $_SESSION['username'] = $username;
                $_SESSION['firstname'] = $namefirt;
                $_SESSION['id'] = $id;
                $_SESSION['success'] = "Login";
                header("location: ../home.php");
            } else {
                $_SESSION['errorlogin'] = "ชื่อผู้ใช้งาน/รหัสผ่าน/ประเภทผู้ใช้งาน ไม่ถูกต้อง";
                header("location: ../home.php#login");
            }
        }
        else {
            echo $query;
            echo mysqli_error($conn);
        }
        
    }else{
        $varerr = "";
        foreach ($error as $e) {
            $varerr .= $e;
            $varerr .= "<br/>";
        }
        $_SESSION['errorlogin'] = $varerr;
        header("location: ../home.php#login");
    }
}
?>