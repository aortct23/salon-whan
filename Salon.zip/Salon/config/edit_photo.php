<?php 

session_start();

include('condb.php');

if(isset($_POST["editphobtn"])) {

    $fileupload = $_POST["fileupload"];
    $id = $_SESSION["idbooking"];
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];

    date_default_timezone_set('Asia/Bangkok');
    $date = date("Ymd");

    $numrand = (mt_rand());
    $upload = $_FILES["fileupload"];
    if($upload !="")  {
        $path ="../img/profile/"; 
        $type = strrchr($_FILES['fileupload']['name'],".");

        $newname = $username.$role.$date.$numrand.$type;
        $path_copy=$path.$newname;
        $path_link="../img/profile/".$newname;

        move_uploaded_file($_FILES["fileupload"]["tmp_name"],$path_copy);

    }
    $updateslip="";
    if($role=="customer"){
        $updateslip = "UPDATE customers SET cus_photo='{$newname}' WHERE cus_user ='{$username}'";
    }else if($role=="emp"){
        $updateslip = "UPDATE employees SET tr_photo='{$newname}' WHERE tr_user ='{$username}'";
    }else if($role=="admin"){//ad_photo
        $updateslip = "UPDATE admin SET ad_photo='{$newname}' WHERE ad_user ='{$username}'";
    }
    $result = mysqli_query($conn,$updateslip) or die ("Error in query : $updateslip ".mysqli_error($conn));

    mysqli_close($conn);

    if($result){
        echo "<script type='text/javascript'>
        alert('เปลี่ยนรูปโปรไฟล์สำเร็จสำเร็จ');
        window.location = '../profile.php';
        </script>";
    }else{
        echo "<script type='text/javascript'>
        alert('เปลี่ยนรูปโปรไฟล์สำเร็จไม่สำเร็จ');
        window.location = '../profile.php';
        </script>";
    }
}
?>