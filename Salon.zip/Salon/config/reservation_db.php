
<?php
session_start();
include('condb.php');
// <!--`reservations`(`reser_id`, `reser_date`, `reser_time`, `tr_id`, `ser_id`, `cus_id`) -->

if (isset($_POST['add'])) {
    $cus_user = $_SESSION['username'];
    $tr_id = $_POST['employee'];
    $ser_id =  $_POST['ser_id'];
    $reser_date = $_POST['datebook'];
    $reser_time = $_POST['timebook'];
    //cus_name,cus_phone,cus_user,cus_email,cus_password
    $sqlcus= "SELECT * FROM customers where cus_user  = '{$cus_user}'";
    $retcus = mysqli_query($conn, $sqlcus);
    if($retcus){
        if(mysqli_num_rows($retcus)==1){
            while ($row = mysqli_fetch_assoc($retcus)) {
                $cus_id = $row['cus_id'];
                $namefirt = $row['cus_name'];
                $username =  $row['cus_user'];


                $insert = "INSERT INTO reservations (reser_date,reser_time,tr_id,ser_id,cus_id,status) 
                VALUES ('$reser_date','$reser_time',$tr_id,'$ser_id','$cus_id','new')";
            //echo $insert;
            $insert_querty = mysqli_query($conn, $insert);
            if ($insert_querty) {
                $_SESSION['status'] = "Inserted";
                header('location: ../list_reservation.php');
            } else {
                echo  "Falied" . $insert;
                //header('location: booking.php');
            }
            }
        }
        
    }
}
?>
