<?php 

    $severname="localhost";
    $username="id21333175_salon";
    $password="Aor_21091992";
    $dbname="id21333175_salon";

    //Create connection
    $conn = mysqli_connect($severname,$username,$password,$dbname);

    //Check connecntion
    if(!$conn) {
        die("Connection failed" . mysqli_connect_error());
    } 
?>