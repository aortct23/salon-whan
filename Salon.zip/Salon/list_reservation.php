<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');
$cus_user = $_SESSION['username'];
$sqlcus= "SELECT * FROM customers where cus_user  = '{$cus_user}'";
    $retcus = mysqli_query($conn, $sqlcus);
    if($retcus){
        if(mysqli_num_rows($retcus)==1){
            while ($row = mysqli_fetch_assoc($retcus)) {
                $cus_id = $row['cus_id'];
                $namefirt = $row['cus_name'];
                $username =  $row['cus_user'];
            }
        }
        
    }
$sql = "SELECT reser_id,reser_date,reser_time,
        (select e.tr_name from employees e where e.tr_id = r.tr_id)tr_name,
        (select e.ser_name from services e where e.ser_id = r.ser_id)ser_name,
        status FROM reservations r where cus_id='$cus_id' and status in  ('new','confirmed') order by reser_date";
$result = mysqli_query($conn, $sql);
$num_rows = mysqli_num_rows($result);

$sqlold = "SELECT reser_id,reser_date,reser_time,
(select e.tr_name from employees e where e.tr_id = r.tr_id)tr_name,
(select e.ser_name from services e where e.ser_id = r.ser_id)ser_name,
status FROM reservations r where cus_id='$cus_id' and status not in ('new','confirmed')  order by reser_date";
$resulodl = mysqli_query($conn, $sqlold);
$num_rowsii = mysqli_num_rows($resulodl);

?>
<main id="main">
  <section class="inner-page">
    <div class="container">
      <div class="section-title">
        <h2>การจองของฉัน</h2>
      </div>
      <div class="row">
      <div class="card">
        <div class="card-header">
          การจองล่าสุด
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12">

            </div>
          </div>
          
          <div class="row">
            <div class="col-12">
              <table class="table table-hover table-sm" id="table1">
                <thead>
                  <tr class="table-primary">
                    <th scope="col">รหัสบริการ</th>
                    <th scope="col">วันที่จอง</th>
                    <th scope="col">เวลาที่จอง</th>
                    <th scope="col">บริการ</th>
                    <th scope="col">ช่าง</th>
                    <th scope="col">สถานะ</th>
                    <th scope="col">#</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  //<!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id`  class="img-fluid img-thumbnail" -->
                  while ($row = mysqli_fetch_assoc($result)) {
                  ?>
                    <tr>
                      <td>REV<?php echo $row['reser_id']; ?></td>
                      <td><?php echo $row['reser_date']; ?></td>
                      <td><?php echo $row['reser_time']; ?></td>
                      <td><?php echo $row['ser_name']; ?></td>
                      <td><?php echo $row['tr_name']; ?></td>
                      <td><?php echo $row['status']; ?></td>
                      <td>#</td>
                    </tr>

                  <?php
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      </div>
      <div class="row">
      <div class="card">
        <div class="card-header">
          ประวัติการจอง
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12">
            
            </div>
          </div>
          
          <div class="row">
            <div class="col-12">
              <table class="table table-hover table-sm" id="tables">
                <thead>
                  <tr class="table-primary">
                    <th scope="col">รหัสบริการ</th>
                    <th scope="col">วันที่จอง</th>
                    <th scope="col">เวลาที่จอง</th>
                    <th scope="col">บริการ</th>
                    <th scope="col">ช่าง</th>
                    <th scope="col">สถานะ</th>
                    <th scope="col">#</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  //<!--`ser_id`, `ser_name`, `ser_list`, `ser_detail`, `ser_photo`, `ser_price`, `tr_id`  class="img-fluid img-thumbnail" -->
                  while ($row = mysqli_fetch_assoc($resulodl)) {
                  ?>
                    <tr>
                      <td>REV<?php echo $row['reser_id']; ?></td>
                      <td><?php echo $row['reser_date']; ?></td>
                      <td><?php echo $row['reser_time']; ?></td>
                      <td><?php echo $row['ser_name']; ?></td>
                      <td><?php echo $row['tr_name']; ?></td>
                      <td><?php echo $row['status']; ?></td>
                      <td>#</td>
                    </tr>

                  <?php
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  </section>



</main><!-- End #main -->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
        $(document).ready(function () {
           // $("#tables").DataTable();
        });
</script>
</script>
<?php
include('include/foot.php');
mysqli_close($conn);
?>