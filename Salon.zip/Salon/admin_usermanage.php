<?php
session_start();
//$_SESSION["username"]="";
include('include/header.php');
include('config/condb.php');

$sqlcus = "SELECT * FROM customers";
$rs_cus = mysqli_query($conn, $sqlcus);
$num_rowscus = mysqli_num_rows($rs_cus);

$sqlemployee = "SELECT * FROM employees";
$rs_employee = mysqli_query($conn, $sqlemployee);
$num_rowsemp = mysqli_num_rows($rs_employee);

$sqladmin = "SELECT * FROM admin";
$rs_admin = mysqli_query($conn, $sqladmin);
$num_rowssdmin = mysqli_num_rows($rs_admin);

?>
<main id="main">
    <section class="inner-page">
        <div class="container">
            <div class="section-title">
                <h2>จัดการผู้ใช้งาน</h2>
            </div>
            <div class="card">
                <div class="card-header">
                    รายชื่อลูกค้า
                </div>
                <div class="card-body">
                    <div class="row">
                <div class="col-12">
                        <?php
                        if (isset($_SESSION['errorsddcus']) && $_SESSION['errorsddcus'] != "") {
                        ?>
                          <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['errorsddcus']; ?>
                          </div>
                        <?php
                          unset($_SESSION['errorsddcus']);
                        }
                        if (isset($_SESSION['successaddcus']) && $_SESSION['successaddcus'] != "" && $_SESSION['successaddcus'] == "Regis commplet") {
                        ?>
                          <div class="alert alert-success" role="alert">
                            เพิ่มข้อมูลเรียบร้อย
                          </div>
                        <?php
                          unset($_SESSION['successaddcus']);

                        }
                        ?>
                      </div>
                    </div>
                    <a href="#" class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#addcustomer">เพิ่มลูกค้า</a>
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover table-sm  ">
                                <thead>
                                    <tr class="table-primary">
                                        <th scope="col">รหัสลูกค้า</th>
                                        <th scope="col">ชื่อลูกค้า</th>
                                        <th scope="col">ชื่อผู้ใช้งานลูกค้า</th>
                                        <th scope="col">เบอร์โทรศัพท์</th>
                                        <th scope="col">#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //cus_name,cus_phone,cus_user,cus_email,cus_password
                                    while ($row = mysqli_fetch_assoc($rs_cus)) {
                                    ?>
                                        <tr>
                                            <td>CUS<?php echo $row['cus_id']; ?></td>
                                            <td><?php echo $row['cus_name']; ?></td>
                                            <td><?php echo $row['cus_user']; ?></td>
                                            <td><?php echo $row['cus_phone']; ?></td>
                                            <td><button class="btn btn-sm btn-primary">แก้ไข</button><button class="btn btn-sm btn-danger">ลบ</button></td>
                                        </tr>

                                    <?php
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    รายชื่อช่าง
                </div>
                <div class="card-body">
                <div class="row">
                <div class="col-12">
                        <?php
                        if (isset($_SESSION['errorsddemp']) && $_SESSION['errorsddemp'] != "") {
                        ?>
                          <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['errorsddemp']; ?>
                          </div>
                        <?php
                          unset($_SESSION['errorsddemp']);
                        }
                        if (isset($_SESSION['successaddemp']) && $_SESSION['successaddemp'] != "" && $_SESSION['successaddemp'] == "Regis commplet") {
                        ?>
                          <div class="alert alert-success" role="alert">
                            เพิ่มข้อมูลเรียบร้อย
                          </div>
                        <?php
                          unset($_SESSION['successaddemp']);

                        }
                        ?>
                      </div>
                    </div>
                    <a href="#" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#addemp">เพิ่มช่าง</a>
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover table-sm  ">
                                <thead>
                                    <tr class="table-secondary">
                                        <th scope="col">รหัสช่าง</th>
                                        <th scope="col">ชื่อช่าง</th>
                                        <th scope="col">ชื่อผู้ใช้งานช่าง</th>
                                        <th scope="col">เบอร์โทรศัพท์</th>
                                        <th scope="col">#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //`tr_id`, `tr_name`, `tr_tel`, `tr_user`, `tr_email`, `tr_password`, `tr_ photo`
                                    while ($row = mysqli_fetch_assoc($rs_employee)) {
                                    ?>
                                        <tr>
                                            <td>TR<?php echo $row['tr_id']; ?></td>
                                            <td><?php echo $row['tr_name']; ?></td>
                                            <td><?php echo $row['tr_user']; ?></td>
                                            <td><?php echo $row['tr_tel']; ?></td>
                                            <td><button class="btn btn-sm btn-primary">แก้ไข</button><button class="btn btn-sm btn-danger">ลบ</button></td>
                                        </tr>

                                    <?php
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    รายชื่อเจ้าของร้าน
                </div>
                <div class="card-body">
                <div class="row">
                <div class="col-12">
                        <?php
                        if (isset($_SESSION['errorsddadmin']) && $_SESSION['errorsddadmin'] != "") {
                        ?>
                          <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['errorsddadmin']; ?>
                          </div>
                        <?php
                          unset($_SESSION['errorsddadmin']);
                        }
                        if (isset($_SESSION['successaddadmin']) && $_SESSION['successaddadmin'] != "" && $_SESSION['successaddadmin'] == "Regis commplet") {
                        ?>
                          <div class="alert alert-success" role="alert">
                            เพิ่มข้อมูลเรียบร้อย
                          </div>
                        <?php
                          unset($_SESSION['successaddadmin']);

                        }
                        ?>
                      </div>
                    </div>
                    <a href="#" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addadmin">เพิ่มเจ้าของร้าน</a>
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-hover table-sm  ">
                                <thead>
                                    <tr class="table-dark">
                                        <th scope="col">รหัสช่าง</th>
                                        <th scope="col">ชื่อช่าง</th>
                                        <th scope="col">ชื่อผู้ใช้งานช่าง</th>
                                        <th scope="col">เบอร์โทรศัพท์</th>
                                        <th scope="col">#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //(`ad_id`, `ad_name`, `ad_phone`, `ad_user`, `ad_email`, `ad_password`
                                    while ($row = mysqli_fetch_assoc($rs_admin)) {
                                    ?>
                                        <tr>
                                            <td>AD<?php echo $row['ad_id']; ?></td>
                                            <td><?php echo $row['ad_name']; ?></td>
                                            <td><?php echo $row['ad_user']; ?></td>
                                            <td><?php echo $row['ad_phone']; ?></td>
                                            <td><button class="btn btn-sm btn-primary">แก้ไข</button><button class="btn btn-sm btn-danger">ลบ</button></td>
                                        </tr>

                                    <?php
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal addcus -->
<div class="modal fade" id="addcustomer" tabindex="-1" aria-labelledby="addcustomerLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addcustomerLabel">เพิ่มลูกค้า</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="config/manage_userdb.php" method="post">
      <div class="modal-body">
      
          <!-- <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ชื่อบริการ</label>
            <input type="text" class="form-control" name="add_name" id="add_name" >
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ราคา</label>
            <input type="number" class="form-control" id="add_price" name="add_price">
          </div> -->
          <div class="form-group mb-3">
                        <input type="text" name="cus_name" class="form-control" id="cus_name" placeholder="ชื่อ-สกุล" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" name="cus_user" class="form-control" id="cus_user" placeholder="ชื่อผู้ใช้งาน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" class="form-control" name="cus_phone" id="cus_phone" placeholder="เบอร์โทร" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="email" class="form-control" name="cus_email" id="cus_email" placeholder="อีเมล" required>
                      </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-primary" name="addcusbtn">ยืนยัน</button>
      </div>
      </form>
    </div>
  </div>
</div>
 <!-- Modal addemp -->
 <div class="modal fade" id="addemp" tabindex="-1" aria-labelledby="addempLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addempLabel">เพิ่มช่าง</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="config/manage_userdb.php" method="post">
      <div class="modal-body">
      
          <!-- <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ชื่อบริการ</label>
            <input type="text" class="form-control" name="add_name" id="add_name" >
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ราคา</label>
            <input type="number" class="form-control" id="add_price" name="add_price">
          </div> 
        `tr_id`, `tr_name`, `tr_tel`, `tr_user`, `tr_email`, `tr_password`, `tr_ photo`
        -->
          
          <div class="form-group mb-3">
                        <input type="text" name="tr_name" class="form-control" id="tr_name" placeholder="ชื่อ-สกุล" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" name="tr_user" class="form-control" id="tr_user" placeholder="ชื่อผู้ใช้งาน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" class="form-control" name="tr_tel" id="tr_tel" placeholder="เบอร์โทร" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="email" class="form-control" name="tr_email" id="tr_email" placeholder="อีเมล" required>
                      </div>
                     
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-primary" name="addempbtn">ยืนยัน</button>
      </div>
      </form>
    </div>
  </div>
</div>
 <!-- Modal addemp -->
 <div class="modal fade" id="addadmin" tabindex="-1" aria-labelledby="addadminLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="addadminLabel">เพิ่มเจ้าของร้าน</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <br>
      <form action="config/manage_userdb.php" method="post">
      <div class="modal-body">
      
          <!-- <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ชื่อบริการ</label>
            <input type="text" class="form-control" name="add_name" id="add_name" >
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">ราคา</label>
            <input type="number" class="form-control" id="add_price" name="add_price">
          </div> 
      (`ad_id`, `ad_name`, `ad_phone`, `ad_user`, `ad_email`, `ad_password`
        -->
          
          <div class="form-group mb-3">
                        <input type="text" name="ad_name" class="form-control" id="ad_name" placeholder="ชื่อ-สกุล" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" name="ad_user" class="form-control" id="ad_user" placeholder="ชื่อผู้ใช้งาน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" class="form-control" name="ad_phone" id="ad_phone" placeholder="เบอร์โทร" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="email" class="form-control" name="ad_email" id="ad_email" placeholder="อีเมล" required>
                      </div>
                     
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-dark" name="addadminbtn">ยืนยัน</button>
      </div>
      </form>
    </div>
  </div>
</div>
</main><!-- End #main -->
<?php
include('include/foot.php');
mysqli_close($conn);
?>