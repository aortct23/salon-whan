<?php

  include('config/condb.php');
  if (isset($_SESSION['username'])) {
    $cus_name = $_SESSION['username'];
    $query = "SELECT * FROM customers WHERE cus_name='$cus_name' ";
    $result = mysqli_query($conn, $query);
    $num_rows = mysqli_num_rows($result);
}
  ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ร้านน้ำหวาน ซาลอน ทำผมครบวงจร</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/barber-pole.png" rel="icon">
  <link href="assets/img/barber-pole.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style>
    .mytextdiv{
  display:flex;
  flex-direction:row;
   align-items: center;
}
.mytexttitle{
  flex-grow:0;
}

.divider{
  flex-grow:1;
  height: 1px;
  background-color: #9f9f9f;
}
</style>
  <!-- =======================================================
  * Template Name: iPortfolio
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="assets/img/barber-pole.png" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light">น้ำหวาน ซาลอน</h1>
        <div class="text-center">
        <?php 
        if((isset($_SESSION['role'])&&$_SESSION['role']!="")&&(isset($_SESSION['username'])&&$_SESSION['username']!="") ){
          echo "<h6 class='text-light'>สวัสดีคุณ ".$_SESSION['firstname']."</h6>";
          $urol="";
         if($_SESSION['role']=="customer")$urol="ลูกค้า";
         else if($_SESSION['role']=="emp")$urol="ช่าง";
         else if($_SESSION['role']=="admin")$urol="เจ้าของร้าน";
         echo "<p class='text-light'>ระดับ ".$urol."</p>";
        }
        ?>
        </div>
        

        <!-- <div class="social-links mt-3 text-center">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div> -->
      </div>
<hr>
      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <!-- .nav-หน้าแรก -->
          <li><a href="home.php" class="nav-link scrollto"><i class="bx bx-home"></i> <span>หน้าหลัก</span></a></li>

          
<?php 
if((isset($_SESSION['role'])&&$_SESSION['role']!="")&&(isset($_SESSION['username'])&&$_SESSION['username']!="") ){
  echo '
  <li><a href="profile.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>ประวัติส่วนตัว</span></a></li>';

        if($_SESSION['role']=="customer"){
        echo '
                  <li><a href="serviece_our.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>รายการบริการ</span></a></li>
                  <li><a href="resevation.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>จองคิว</span></a></li>
                  <li><a href="list_reservation.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>ดูข้อมูลการจอง</span></a></li>
        ';
        } else if($_SESSION['role']=="emp"){
          echo '
                    <li><a href="trwork_schedule.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>ตารางการทำงาน</span></a></li>
        ';

        } else if($_SESSION['role']=="admin"){
          echo '
          <li><a href="admin_reservation.php" class="nav-link scrollto"><i class="bx bx-user"></i><span>ตารางการจอง</span></a></li>
          <li><a href="admin_serivce.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>จัดการรายการบริการ</span></a></li>
          <li><a href="admin_usermanage.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>จัดการผู้ใช้งาน</span></a></li>
        ';
        } 
        echo '
        <li><a href="logout.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>ออกระบบ</span></a></li>';
}
else
{
  echo '<li><a href="#login" class="nav-link scrollto"><i class="bx bx-user"></i> <span>ลงทะเบียน/เข้าสู่ระบบ</span></a></li>';
}

?>
           <!-- .nav-ลูกค้า -->
           

           <!-- .nav-ช่าง -->
           


          <!-- .nav-admin -->


          
          
          <!--<li><a href="#resume" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Resume</span></a></li>
          <li><a href="#portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Portfolio</span></a></li>
          <li><a href="#services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Services</span></a></li>
          <li><a href="#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact</span></a></li>-->
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->