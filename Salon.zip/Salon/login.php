<main>
    <!-- ======= Contact Section ======= -->
    <section id="login" class="contact">

      <div class="container">
        <div class="section-title">
          <h2>ลงทะเบียน/เข้าสู่ระบบ</h2>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-12">
                    <div class="row">
                      <div class="col-12">
                        <?php
                        if (isset($_SESSION['errorregis']) && $_SESSION['errorregis'] != "") {
                        ?>
                          <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['errorregis']; ?>
                          </div>
                        <?php
                          unset($_SESSION['errorregis']);
                        }
                        if (isset($_SESSION['successregid']) && $_SESSION['successregid'] != "" && $_SESSION['successregid'] == "Regis commplet") {
                        ?>
                          <div class="alert alert-success" role="alert">
                            ลงทะเบียนสำเร็จ กรุณาเข้าสู่ระบบ
                          </div>
                        <?php
                          unset($_SESSION['successregid']);
                          unset($_SESSION['username']);
                          unset($_SESSION['urole']);
                        }
                        ?>
                      </div>
                    </div>
                    <form action="config/regis_db.php" method="POST">
                      <div class="form-group mb-3">
                        <input type="text" name="cus_name" class="form-control" id="cus_name" placeholder="ชื่อ-สกุล" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" name="cus_user" class="form-control" id="cus_user" placeholder="ชื่อผู้ใช้งาน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="text" class="form-control" name="cus_phone" id="cus_phone" placeholder="เบอร์โทร" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="email" class="form-control" name="cus_email" id="cus_email" placeholder="อีเมล" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="password" name="cus_password" class="form-control" id="cus_password" placeholder="รหัสผ่าน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="password" name="repassword" class="form-control" id="repassword" placeholder="ยืนยันรหัสผ่าน" required>
                      </div>
                      <div class="text-center"><button type="submit" class="btn btn-info" name="registbtn">ลงทะเบียน</button></div>
                    </form>

                  </div>
                </div>


              </div>
            </div>
            <div class="mytextdiv">
              <div class="divider"></div>
              <div class="mytexttitle">
                OR
              </div>
              <div class="divider"></div>
            </div>
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="row">
                    <div class="col-12">
                      <?php
                      if (isset($_SESSION['errorlogin']) && $_SESSION['errorlogin'] != "") {
                      ?>
                        <div class="alert alert-danger" role="alert">
                          <?php echo $_SESSION['errorlogin']; ?>
                        </div>
                      <?php
                        unset($_SESSION['errorlogin']);
                      }
                      ?>
                    </div>
                  </div>
                  <div class="col-12">
                    <form action="config/login_db.php" method="POST">
                      <div class="form-group mb-3">
                        <input type="text" class="form-control" name="logingname" id="logingname" placeholder="เบอร์โทรศัพท์/ชื่อผู้ใช้งาน" required>
                      </div>
                      <div class="form-group mb-3">
                        <input type="password" name="password" class="form-control" id="password" placeholder="รหัสผ่าน" required>
                      </div>
                      <hr>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="urole" id="inlineRadio1" value="customer" >
                        <label class="form-check-label" for="inlineRadio1">ลูกค้า</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="urole" id="inlineRadio2" value="emp">
                        <label class="form-check-label" for="inlineRadio2">ช่าง</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="urole" id="inlineRadio3" value="admin">
                        <label class="form-check-label" for="inlineRadio2">ผู้ดูแลระบบ</label>
                      </div>
                      <div class="text-center"><button type="submit" class="btn btn-primary" name="login_user">เข้าสู่ระบบ</button></div>
                    </form>

                  </div>
                </div>
              </div>





            </div>
          </div>
        </div>

      </div>
    </section><!-- End Contact Section -->

  </main>